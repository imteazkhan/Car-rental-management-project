const API_URL = "http://localhost/car-rental-management-project/API";

export default API_URL